package com.builttoroam.devicecalendar.common

enum class RecurrenceFrequency {
    DAILY, WEEKLY, MONTHLY, YEARLY
}