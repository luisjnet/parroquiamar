package com.builttoroam.devicecalendar.models

class Reminder(val minutes: Int) {
}